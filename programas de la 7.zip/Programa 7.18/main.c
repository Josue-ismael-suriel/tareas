#include <stdio.h>

void inverso(char *);

int main(void)
{
    char fra[50];
    printf("\nIngrese la l�nea de texto: ");
    gets(fra);
    printf("\nLa l�nea de texto en forma inversa es: ");
    inverso(fra);
    printf("\n");
    return 0;
}

void inverso(char *cadena)
{
    if (cadena[0] != '\0')
    {
        inverso(&cadena[1]);
        putchar(cadena[0]);
    }
}
